﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace WpfTest
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
			this.Loaded += MainWindow_Loaded;
		}

		void MainWindow_Loaded(object sender, RoutedEventArgs e)
		{
			this.DataContext = new DataContext() { DecimalValue = 123.45M };

			TextBox tb = new TextBox() { MinWidth = 50 };
			Binding binding = new Binding("OtherValue") { NotifyOnValidationError = true, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged };
			tb.SetBinding(TextBox.TextProperty, binding);

			stackPanel.Children.Add(tb);



		}
	}

	public class DataContext : INotifyDataErrorInfo, INotifyPropertyChanged
	{
		public decimal DecimalValue { get; set; }
		public decimal OtherValue { get; set; }
		public string Msg { get; set; }

		public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;

		public System.Collections.IEnumerable GetErrors(string propertyName)
		{
			return null;
		}

		public bool HasErrors
		{
			get { return false; }
		}

		public event PropertyChangedEventHandler PropertyChanged;

		protected void NotifyPropertyChanged(string propName)
		{
			if (this.PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(propName));
		}
	}
}
